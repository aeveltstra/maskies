# Revision history for maskies

## 0.1.0.0 -- YYYY-mm-dd

* First version. Released on an unsuspecting world.

## 0.1.0.1 -- 2020-08-28

* Renaming to Maskies.
* Added stages. 
* Rewired stages.
* Settled on a game loop architecture.
* Moved game handling functions to top of source file,
  leaving room underneath for all the stages.
