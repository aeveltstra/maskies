import Distribution.simple
main = defaultMain
